package com.if3a.pab1_2125250042_uts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {
    private TextView tvNama, tvEmail, tvKota, tvTanggal;
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        tvNama = findViewById(R.id.tv_nama);
        tvEmail = findViewById(R.id.tv_email);
        tvKota = findViewById(R.id.tv_kota);
        tvTanggal = findViewById(R.id.tv_tanggal);
        btnBack = findViewById(R.id.btn_Kembali);

        Intent intent = getIntent();

        tvNama.setText(intent.getStringExtra("varUser"));
        tvEmail.setText(intent.getStringExtra("varEmail"));
        tvKota.setText(intent.getStringExtra("varKota"));
        tvTanggal.setText(intent.getStringExtra("varDate"));


        //Kembali
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ResultActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_option, menu);
        return super.onCreateOptionsMenu(menu);
    }
}