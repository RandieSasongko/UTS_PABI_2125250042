package com.if3a.pab1_2125250042_uts;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.Calendar;

public class RegisterActivity extends AppCompatActivity {
    private EditText etUsername, etPassword, etBirth, etEmail;
    private Spinner spKota;
    private Button btnSignUp;
    private ActionBar judulBar;

    DatePickerDialog.OnDateSetListener setListener;
    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        judulBar = getSupportActionBar();

        //Date
        etBirth = findViewById(R.id.et_calendar);

        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);

        etBirth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(RegisterActivity.this,
                        android.R.style.Theme_DeviceDefault_Dialog_MinWidth, setListener, year, month, day);
                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.show();
            }
        });

        setListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month,
                                  int dayOfMonth) {
                month = month+1;
                String date = day+"/"+month+"/"+year;
                etBirth.setText(date);

                Intent intent = new Intent();
                intent.putExtra("varDate", date);
            }
        };

        //Deklarasi
        etUsername = findViewById(R.id.et_username);
        etPassword = findViewById(R.id.et_password);
        spKota = findViewById(R.id.sp_kota);
        etEmail = findViewById(R.id.et_email);
        btnSignUp = findViewById(R.id.btn_signUp);

        builder = new AlertDialog.Builder(this);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user, email, kota, tanggal, pass;

                user = etUsername.getText().toString();
                pass = etPassword.getText().toString();
                email = etEmail.getText().toString();
                kota = spKota.getSelectedItem().toString();
                tanggal = etBirth.getText().toString();

                if(user.trim().isEmpty())
                {
                    etUsername.setError("Username Tidak Boleh Kosong");
                }
                else if(email.trim().isEmpty())
                {
                    etEmail.setError("Email Tidak Boleh Kosong");
                }
                else if(pass.trim().isEmpty())
                {
                    etPassword.setError("Password Tidak Boleh Kosong");
                }
                else if(tanggal.trim().isEmpty())
                {
                    etBirth.setError("Tanggal Tidak Boleh Kosong");
                }
                else
                {
                    Intent intent = new Intent(RegisterActivity.this, ResultActivity.class);

                    intent.putExtra("varUser", user);
                    intent.putExtra("varKota", kota);
                    intent.putExtra("varEmail", email);
                    intent.putExtra("varDate", tanggal);

                    builder.setTitle("Alert!!")
                            .setMessage("Do you want to close the application")
                            .setCancelable(true)
                            .setPositiveButton("Yes", new
                                    DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface
                                                                    dialogInterface, int i) {
                                            startActivity(intent);
                                        }
                                    })
                            .setNegativeButton("No", new
                                    DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface
                                                                    dialogInterface, int i) {
                                            dialogInterface.cancel();
                                        }
                                    })
                            .show();
                }
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_option, menu);
        return super.onCreateOptionsMenu(menu);
    }
}